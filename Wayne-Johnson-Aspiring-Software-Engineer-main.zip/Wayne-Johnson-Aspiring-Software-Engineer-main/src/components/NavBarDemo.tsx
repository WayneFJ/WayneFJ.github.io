
import { Home, User, Music } from 'lucide-react'
import { TubelightNavbarDemo } from "@/components/ui/tubelight-navbar"

export function NavBarDemo() {
  return <TubelightNavbarDemo />
}
