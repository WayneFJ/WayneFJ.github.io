
export function SplashCursorDemo() {
  return null;
}
